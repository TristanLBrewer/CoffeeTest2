﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CoffeeTest.Pages
{
    public class IndexModel : PageModel
    {
        //Note: I wanted to make other classes to show use of objects (and ideally some constructors or inheritance) but couldn't find a reason that wasn't just making the code unnecessarily long/convoluted. I'd love to hear any tips on how I can improve in the future, Cheers.
        private readonly ILogger<IndexModel> _logger;

        public IndexModel(ILogger<IndexModel> logger)
        {
            _logger = logger;
        }

        public void OnGet()
        {
            prep = "Welcome!";
        }

        public string drink { get; set; }
        public string boiling { get; set; }
        public string prep { get; set; }
        public string pour { get; set; }
        public string add { get; set; }
        public string allDone { get; set; }

        //Button Code, would've liked to simplify this into just one OnPost method and I'm sure there is a way I just couldn't find it. If I knew how to see the pressed button's id in this code here I could have done a single method with an if or switch statement that would set the 'check' variable based on which button is used. (Could be possible with ActionResult or in js)
        public void OnPostLemonTea()
        {
            MakeDrink(1);
        }

        public void OnPostCoffee()
        {
            MakeDrink(2);
        }

        public void OnPostHotChocolate()
        {
            MakeDrink(3);
        }

        //Next customer button, clears text.
        public void OnPostClearText()
        {
            boiling = prep = add = pour = string.Empty;
            prep = "Welcome!";
        }

        public void MakeDrink(int check)
        {
            //Chose to do a switch statement for future proofing. Will be very easy to add items in the future, just add a new case and a new button method.
            switch (check)
            {
                case 1:
                    drink = "lemon tea";
                    prep = "Steeping water in the tea...";
                    add = "Adding lemon...";
                    break;
                case 2:
                    drink = "coffee";
                    prep = "Brewing coffee grounds...";
                    add = "Adding sugar and milk...";
                    break;
                case 3:
                    drink = "hot chocolate";
                    prep = "Adding drinking chocolate powder to water...";
                    break;
                default:
                    drink = "";
                    break;
            }
            BoilingWater();
            Pouring();
            AllDone();
        }

        public void BoilingWater()
        {
            boiling = "The water is boiling...";
        }

        public void Pouring()
        {
            pour = $"Pouring your {drink} into the cup...";
        }

        public void AllDone()
        {
            allDone = $"All finished! Enjoy your {drink} :)";
        }
    }

}
